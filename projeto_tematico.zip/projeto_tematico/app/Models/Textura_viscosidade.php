<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Textura_viscosidade extends Model
{
    use HasFactory;
    protected $table = "textura_viscosidade";
}
