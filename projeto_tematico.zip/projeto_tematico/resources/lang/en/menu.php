<?php
return [
    'search' => 'Search',
    'blog' => 'Blog',
    'Home' => 'Dashboard',
    'Produtos' => 'Products',
    'Clientes' => 'Clients',
    'Operadores' => 'Operators',
    'Fornecedores' => 'Suppliers',
    'Entradas' => 'Entries',
    'Químico' => 'Chemical',
    'Não Químico' => 'Non Chemical',
    'Saídas' => 'Check Outs',
    'Operadores historico' => 'Operators',
    'Registo de Entrada' => 'New Entry',
    'Registo de Saída' => 'New Check out',
    'Novo produto' => 'Add Product',
    'Histórico de Movimentos' => 'Transactions History',
    'Registos' => 'Registration'
];