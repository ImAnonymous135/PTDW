<?php
return [
    'search' => 'Search',
    'blog' => 'Blog',
    'Home' => 'Página Inicial',
    'Produtos' => 'Produtos',
    'Clientes' => 'Clientes',
    'Operadores' => 'Operadores',
    'Fornecedores' => 'Fornecedores',
    'Entradas' => 'Entradas',
    'Químico' => 'Químico',
    'Não Químico' => 'Não Químico',
    'Saídas' => 'Saídas',
    'Operadores historico' => 'Operadores',
    'Registo de Entrada' => 'Nova Entrada',
    'Registo de Saída' => 'Nova Saída',
    'Novo produto' => 'Adicionar Produto',
    'Histórico de Movimentos' => 'Histórico de Movimentos',
    'Registos' => 'Registos'
];