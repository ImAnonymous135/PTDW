<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo e(__('text.listaProdutos')); ?></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('text.produtos')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<ul id="menu" class="mfb-component--br mfb-slidein" data-mfb-toggle="hover">
    <li class="mfb-component__wrap">
        <a data-mfb-label= "<?php echo e(__('text.novoProduto')); ?>" class="mfb-component__button--main" href="./produtos/adicionar">
            <i class="mfb-component__main-icon--resting fas fa-plus" style="font-size: 1.5rem;"></i>
        </a>
    </li>
</ul>

<div class="card">
    <div class="card-body">
        <table id="table" class="table table-head-fixed">
            <thead>
                <tr>
                    <th><?php echo e(__('text.designacao')); ?></th>
                    <th><?php echo e(__('text.inventario')); ?></th>
                    <th><?php echo e(__('text.tipo')); ?></th>
                    <th><?php echo e(__('text.acoes')); ?></th>
                </tr>
            </thead>
            <tbody>

            </tfoot>
        </table>
    </div>
    <!-- /.card-body -->
</div>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/mfb.js')); ?>"></script>
<script>

    dataSet = [];

    var json = JSON.parse('<?php echo $produtos?>');

    console.log(json[0].designacao);

    function isQuimicoTexto(isQuimico) {
        if (isQuimico == 1) {
            return "<?php echo __('text.quimico') ?>";
        }
        return "<?php echo __('text.solido') ?>";
    }



    <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
        //dd($produto);
        dataSet.push([
            "<?php echo e($produto->designacao); ?>",
            "<?php echo e($produto->stock_existente); ?>",
            isQuimicoTexto("<?php echo e($produto->is_quimico); ?>"),
            '<div class="btn-group"><a href="./produtos/<?php echo e($produto->id); ?>" type="button" data-toggle="tooltip" title="<?php echo e(__('text.detalhes')); ?>" class="btn btn-primary"><i class="fas fa-eye"></i></a><a href="./entradas/<?php echo e($produto->id); ?>" type="button" data-toggle="tooltip" title="<?php echo e(__('text.novaEntrada')); ?>" class="btn btn-success"><i class="fas fa-plus"></i></a></div>'
            ]);
    }
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    $(function () {
    $('#table').DataTable({
        data: dataSet,
        "responsive": true,
        "autoWidth": false,
        "ordering": false,
        language: {
                url: '//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese.json'
        }
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/mfb.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/lista-produtos.blade.php ENDPATH**/ ?>