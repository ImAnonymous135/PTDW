<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo e(__('text.clientes')); ?></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('text.clientes')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!--
    Adicionar o botao no final para a ação como eliminar ou mudar de cargo ou assim
-->
<?php $__env->startSection('content'); ?>

<ul id="menu" class="mfb-component--br mfb-slidein" data-mfb-toggle="hover">
    <li class="mfb-component__wrap">
        <a data-mfb-label="<?php echo e(__('text.novoCliente')); ?>" class="mfb-component__button--main" href="../clientes/adicionar">
            <i class="mfb-component__main-icon--resting fas fa-plus" style="font-size: 1.5rem;"></i>
        </a>
    </li>
</ul>

<div class="card">
    <div class="card-body">
        <table id="table" class="table table-head-fixed">
            <thead>
                <tr>
                    <th><?php echo e(__('text.designacao')); ?></th>
                    <th><?php echo e(__('text.nomeResponsavel')); ?></th>
                    <th><?php echo e(__('text.emailResponsavel')); ?></th>
                    <th><?php echo e(__('text.nomeSolicitante')); ?></th>
                    <th><?php echo e(__('text.emailSolicitante')); ?></th>
                    <th><?php echo e(__('text.observacoes')); ?></th>
                    <th><?php echo e(__('text.acoes')); ?></th>
                </tr>
            </thead>
        </table>
    </div>
    <!-- /.card-body -->
</div>

<div class="modal fade" id="modal-default" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="eliminar">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('text.eliminar')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><?php echo e(__('text.confirmarEliminarCliente')); ?></p>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('text.nao')); ?></button>
                    <button type="submit" class="btn btn-primary toastrDefaultSuccess" ><?php echo e(__('text.sim')); ?></button>
                </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal fade" id="modal-default1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(__('text.editarCliente')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form method="POST" id="edit">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body w-200">
                <div class="row">
                    <div class="col-sm-6">
                    <div class="form-group">
                    <label><?php echo e(__('text.designacao')); ?></label>
                    <input type="text"  class="form-control <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="designacao" name="designacao" value=<?php echo e(old('designacao')); ?>>
                    <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                    <label><?php echo e(__('text.nomeResponsavel')); ?></label>
                    <input type="text"  class="form-control <?php $__errorArgs = ['nomeResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomeResponsavel" name="nomeResponsavel" value=<?php echo e(old('nomeResponsavel')); ?>>
                    <?php $__errorArgs = ['nomeResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                    <div class="form-group">
                    <label><?php echo e(__('text.emailResponsavel')); ?></label>
                    <input  type="text" class="form-control <?php $__errorArgs = ['emailResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="emailResponsavel" name="emailResponsavel" value=<?php echo e(old('emailResponsavel')); ?>>
                    <?php $__errorArgs = ['emailResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('text.nomeSolicitante')); ?></label>
                            <input type="text" class="form-control " name="nomeSolicitante" id="nomeSolicitante"
                                    value=<?php echo e(old('nomeSolicitante')); ?>>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('text.observacoes')); ?></label>
                            <textarea class="form-control" name="observacoes" id="observacoes" cols="30" rows="3"
                                    maxlength="100"><?php echo e(old('observacoes')); ?></textarea>
                        </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="form-group">
                    <label><?php echo e(__('text.emailSolicitante')); ?></label>
                    <input type="text"   class="form-control <?php $__errorArgs = ['emailSolicitante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="emailSolicitante" name="emailSolicitante" value=<?php echo e(old('emailSolicitante')); ?>> 
                    <?php $__errorArgs = ['emailSolicitante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                    </div>
                </div>

                </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('text.cancelar')); ?></button>
                <button type="submit" class="btn btn-primary toastrDefaultSuccess1"
                    ><?php echo e(__('text.guardar')); ?></button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal fade" id="modal-default2" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(__('text.informacaoCliente')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
            
                <p class="font-weight-bold"><?php echo e(__('text.designacao')); ?>: <span class="font-weight-normal" id="designacaoSpan"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.nomeResponsavel')); ?>: <span class="font-weight-normal" id="nomeRspan"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.emailResponsavel')); ?>: <span class="font-weight-normal" id="emailRsapn"></span>
                </p>
                <p class="font-weight-bold"><?php echo e(__('text.nomeSolicitante')); ?>: <span class="font-weight-normal" id="nomeSspan"></span>
                </p>
                <p class="font-weight-bold"><?php echo e(__('text.emailSolicitante')); ?>: <span class="font-weight-normal" id="emailSspan"></span>
                </p>
                <p class="font-weight-bold"><?php echo e(__('text.observacoes')); ?>: <span class="font-weight-normal" id="observacoes1"></span></p>
            
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<br>
<br>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/mfb.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();
    });
</script>

<script>
<?php if(null !== session()->get( 'toast' )): ?>
        <?php if(session()->get( 'toast' )== 'editSuccess'): ?>
            toastr.success('<?php echo e(__('text.editadoSucesso')); ?>')
        <?php elseif(session()->get( 'toast' ) == 'deleteSuccess'): ?>
            toastr.success('<?php echo e(__('text.eliminadoSucesso')); ?>')
        <?php elseif(session()->get( 'toast' ) == 'error'): ?>
            toastr.error('erro')
        <?php endif; ?>
    <?php endif; ?>

    $(function () {
    $('#table').DataTable({
        "responsive": true,
        "autoWidth": false,
        language: {
                url: '//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese.json'
        },
        "processing": true,
            "serverSide": true,
            "ajax": "<?php echo e(route('APIlistaClientes')); ?>",
            "columns": [
                { "data": 'designacao' },
                { "data": 'nomeOperadores' },
                { "data": 'emailOperadores' },
                { "data": 'nomeSolicitante' },
                { "data": 'emailSolicitante'},
                { "data": 'observacoes'},
                { "data": 'buttons'}
            ]
    });
  });

  function elim(id){
        $('#eliminar').attr('action', '/clientes/'+id);
        $('#modal-default').modal('show');
    }

    function info(id,modal) {
        console.log(id);
        $.ajax({
               type:'GET',
               url:'api/clientes/'+id,
               success: function(info) {
                info = JSON.parse(info);
                console.dir(info);
            if(modal){
                $('#modal-default2').modal('show');
                $('#designacaoSpan').text(info[0].designacao);
                $('#nomeRspan').text(info[0].nomeOperadores);
                $('#emailRsapn').text(info[0].emailOperadores);
                $('#nomeSspan').text(info[0].nomeSolicitante);
                $('#emailSspan').text(info[0].emailSolicitante);
                $('#observacoes1').text(info[0].observacoes);
            }else{
                $('#edit').attr('action', '/clientes/'+id);
                $('#modal-default1').modal('show');
                $('#designacao').val(info[0].designacao);
                $('#nomeResponsavel').val(info[0].nomeOperadores);
                $('#emailResponsavel').val(info[0].emailOperadores);
                $('#nomeSolicitante').val(info[0].nomeSolicitante);
                $('#observacoes').val(info[0].observacoes);
                $('#emailSolicitante').val(info[0].emailSolicitante);
            }
        }
        });
        console.dir(info);
        console.dir(modal);
    }

</script>
<?php echo $__env->make('sub-views.exports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
<link href="<?php echo e(asset('css/mfb.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/clientes.blade.php ENDPATH**/ ?>