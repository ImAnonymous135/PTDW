<?php $__env->startSection('content_header'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">
                        <?php echo e(__('text.registarEntrada')); ?>

                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="../">Home</a></li>
                        <?php if(isset($produto)): ?>
                            <li class="breadcrumb-item "><a href="../produtos"><?php echo e(__('text.produtos')); ?></a></li>
                        <?php endif; ?>
                        <li class="breadcrumb-item active"><?php echo e(__('text.entrada')); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="card-body">
                    
                        

                        
              
                <form method="POST" action="/entradas/adicionar">
                    <?php echo csrf_field(); ?>
                <div id="quimicos">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label><?php echo e(__('text.designacao')); ?></label>
                        <select class="select-search form-control" id="state" name="state">
                            <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>.<?php echo e($item->designacao); ?>"><?php echo e($item->designacao); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.dataEntrada')); ?></label>
                    <input type="date" class="form-control" id="dataEntrada" value=<?php echo e($date); ?> name="dataEntrada" readonly>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.dataValidade')); ?></label>
                    <input type="date" class="form-control" id="dataValidade" value=<?php echo e($date); ?> name="dataValidade">
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.numeroDeEmbalagens')); ?></label>
                    <input type="number" class="form-control" id="numeroEmbalagens" name="numeroEmbalagens">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.identificacaoEmbalagem')); ?></label>
                    <input type="text" class="form-control" id="identificacaoEmbalagens" name="identificacaoEmbalagens" readonly>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.tipoEmbalagem')); ?></label>
                    <select class="form-control input-group-append" id="tipoEmbalagem" name="tipoEmbalagem">
                        <?php $__currentLoopData = $tipoEmbalagem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->tipo_embalagem); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.capacidadeEmbalagem')); ?></label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="capacidadeEmbalagem" placeholder=""
                            name="capacidadeEmbalagem">
                        <select class="form-control input-group-append" id="tipo" name="tipo" disabled>
                            <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->desginacao); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-1">
                <div class="form-group">
                    <label><?php echo e(__('text.sala')); ?></label>
                    <input type="text" class="form-control" id="sala" name="sala" placeholder="">
                </div>
            </div>
            <div class="col-sm-1">
                <div class="form-group">
                    <label><?php echo e(__('text.armario')); ?></label>
                    <input type="text" class="form-control" id="armario" name="armario" placeholder="">
                </div>
            </div>
            <div class="col-sm-1">
                <div class="form-group">
                    <label><?php echo e(__('text.prateleira')); ?></label>
                    <input type="text" class="form-control" id="prateleira" name="prateleira" placeholder="">
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.pesoBruto')); ?></label>
                    <div class="input-group">
                        <input type="number" class="form-control" id="pesoBruto" name="pesoBruto" placeholder="">
                        <div class="input-group-append">
                            <span class="input-group-text"><?php echo e(__('text.gramas')); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.marca')); ?></label>
                    <input type="text" class="form-control" id="marca" name="marca" placeholder="">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.referencia')); ?></label>
                    <input type="number" class="form-control" id="referencia" name="referencia" placeholder="">
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.preco')); ?></label>
                    <div class="input-group">
                        <input type="number" class="form-control" id="preco" name="preco" placeholder="">
                        <div class="input-group-append">
                            <span class="input-group-text">€</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-1">
                <div class="form-group">
                    <label><?php echo e(__('text.taxa')); ?> iva</label>
                    <div class="input-group">
                        <input type="number" class="form-control" id="taxa" name="taxa" placeholder="">
                        <div class="input-group-append">
                            <span class="input-group-text">%</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.estadoFisico')); ?></label>
                    <select class="form-control" id="estadoFisico" name="estadoFisico">
                        <?php $__currentLoopData = $estadoFisico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->estado_fisico); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    <label><?php echo e(__('text.texturaOuViscosidade')); ?></label>
                    <select class="form-control" id="texturaViscosidade" , name="texturaViscosidade">
                        <?php $__currentLoopData = $textura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->textura_viscosidade); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label><?php echo e(__('text.observacoes')); ?></label>
                    <textarea class="form-control" rows="3" maxlength="100" placeholder="" id="observacao"
                        name="observacao"></textarea>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.fornecedor')); ?></label>
                    <input type="text" class="form-control" id="fornecedor" name="fornecedor" placeholder="">
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.operador')); ?></label>
                    <input type="text" class="form-control" id="operador" name="operador" placeholder="">
                </div>
            </div>

        </div>
    </div>
    <div class="d-flex flex-row justify-content-end">
        <span class="mr-2">
            <input type="submit" class="btn btn-block btn-primary" value="<?php echo e(__('text.submeter')); ?>">
        </span>
    </div>
    </form>

    </div>
    </div>

    <div class="">
        <div class="d-flex flex-row justify-content-end">
            <?php if(isset($produto)): ?>
                <span class="mr-2">
                    <button type="button" class="btn btn-block btn-outline-primary"
                        onclick="window.history.back()"><?php echo e(__('text.cancelar')); ?></button>
                </span>
            <?php endif; ?>

        </div>
    </div>
    </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/adicionar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/registo_entrada.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                placeholder: "Selecione os pictogramas..."
            });
        });

        $(document).ready(function() {
            $('.select-search').select2();
            $('#state').change(function(){
                var arraySplit = $(this).val().split(".");
                $('#tipo').val(arraySplit[0]);
            });
        });

    </script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/registo-entrada.blade.php ENDPATH**/ ?>