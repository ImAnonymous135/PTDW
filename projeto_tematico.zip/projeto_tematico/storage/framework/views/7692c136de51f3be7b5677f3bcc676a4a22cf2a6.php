<?php $__env->startSection('content_header'); ?>
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark"><?php echo e(__('text.registarSaida')); ?></h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="../">Home</a></li>
          <li class="breadcrumb-item active"><?php echo e(__('text.movimentosSaida')); ?></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('sub-views.export-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card">
  <div class="card-body">
  <div class="form-group">
                <label class="font-weight-normal"><?php echo e(__('text.tipoEmbalagem')); ?>:</label>
                <div class="input-group-prepend">
                    <select id="pesquisa" class="select form-control" name="pesquisa">
                        <option value="produto">Produto</option>
                        <option value="prateleira">Prateleira</option>
                        <option value="armario">Armario</option>
                        <option value="cliente">Cliente</option>
                        <option value="embalagem">Embalagem</option>
                        <option value="solicitante">Solicitante</option>
                        <option value="operador">Operador</option>
                    </select>
                </div>
            </div>
    <table id="table" class="table table-bordered table-striped">
      <thead>
        <tr>
          <th><?php echo e(__('text.produto')); ?></th>
          <th><?php echo e(__('text.localizacao')); ?></th>
          <th><?php echo e(__('text.embalagem')); ?></th>
          <th><?php echo e(__('text.solicitante')); ?></th>
          <th><?php echo e(__('text.operador')); ?></th>
          <th><?php echo e(__('text.data')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
  <!-- /.card-body -->
</div>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/mfb.js')); ?>"></script>

<script>
  $(function () {
    var table = $('#table').DataTable({
      "responsive": true,
      "autoWidth": false,
      language: {
            url: '//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese.json'
        },
        "processing": true,
            "serverSide": true,
            "ajax": "<?php echo e(route('APISaidas')); ?>",
            "columns": [
                { "data": 'designacao' },
                { "data": 'localizacao' },
                { "data": 'embalagem' },
                { "data": 'solicitante' },
                { "data": 'operador' },
                { "data": 'data' }
            ]
    });
    table.on('preXhr.dt', function (e, settings, data) {
            data.pesquisa = $('#pesquisa').val();
        });
  });
</script>
<?php echo $__env->make('sub-views.exports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/mfb.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/saidas.blade.php ENDPATH**/ ?>