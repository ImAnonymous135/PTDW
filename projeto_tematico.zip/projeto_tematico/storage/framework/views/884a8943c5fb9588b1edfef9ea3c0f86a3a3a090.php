<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo e(__('text.fornecedores')); ?></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('text.fornecedores')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<ul id="menu" class="mfb-component--br mfb-slidein" data-mfb-toggle="hover">
    <li class="mfb-component__wrap">
        <a data-mfb-label="<?php echo e(__('text.novoFornecedor')); ?>" class="mfb-component__button--main"
            href="./fornecedores/adicionar">
            <i class="mfb-component__main-icon--resting fas fa-plus" style="font-size: 1.5rem;"></i>
        </a>
    </li>
</ul>

<div class="card">
    <div class="card-body">
        <table id="table" class="table table-head-fixed">
            <thead>
                <tr>
                    <th><?php echo e(__('text.fornecedores')); ?></th>
                    <th><?php echo e(__('text.morada')); ?></th>
                    <th><?php echo e(__('text.localizacao')); ?></th>
                    <th><?php echo e(__('text.codigoPostal')); ?></th>
                    <th><?php echo e(__('text.telefone')); ?></th>
                    <th>NIF</th>
                    <th><?php echo e(__('text.acoes')); ?></th>
                </tr>
            </thead>
            <tbody>

                </tfoot>
        </table>
        <br>
    </div>
</div>
<br>

<div class="modal fade" id="modal-default" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="eliminar">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('text.eliminar')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><?php echo e(__('text.confirmarEliminarFornecedor')); ?></p>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('text.nao')); ?></button>
                    <button id="deleteButton" type="submit" class="btn btn-primary toastrDefaultSuccess"><?php echo e(__('text.sim')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="modal-default1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(__('text.editarFornecedor')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form method="POST" id="edit">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body w-200">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.nome')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="designacao" id="designacao" value=<?php echo e(old('designacao')); ?>>
                                <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.morada')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['morada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="morada" id="morada" value=<?php echo e(old('morada')); ?>>
                                <?php $__errorArgs = ['morada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.localizacao')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['localidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="localidade" id="localidade" value=<?php echo e(old('localidade')); ?>>
                                <?php $__errorArgs = ['localidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.codigoPostal')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['codigo_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="codigo_postal" id="codigo_postal" value=<?php echo e(old('codigo_postal')); ?>>
                                <?php $__errorArgs = ['codigo_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.telefone')); ?></label>
                                <input type="text" class="form-control  <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="telefone" id="telefone" value=<?php echo e(old('telefone')); ?>>
                                <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>NIF</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nif"
                                    id="nif" value=<?php echo e(old('nif')); ?>>
                                <?php $__errorArgs = ['nif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>E-Mail</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" id="email" value=<?php echo e(old('email')); ?>>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.vendedor')); ?> 1</label>
                                <input type="text" class="form-control" name="vendedor_1" id="vendedor_1"
                                    value=<?php echo e(old('vendedor_1')); ?>>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.telefone')); ?> 1</label>
                                <input type="text" class="form-control " name="telemovel_1" id="telemovel_1"
                                    value=<?php echo e(old('telemovel_1')); ?>>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>E-Mail 1</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['email_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email_1" id="email_1" value=<?php echo e(old('email_1')); ?>>
                                <?php $__errorArgs = ['email_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.vendedor')); ?> 2</label>
                                <input type="text" class="form-control" name="vendedor_2" id="vendedor_2"
                                    value=<?php echo e(old('vendedor_2')); ?>>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.telefone')); ?> 2</label>
                                <input type="text" class="form-control " name="telemovel_2" id="telemovel_2"
                                    value=<?php echo e(old('telemovel_2')); ?>>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>E-Mail 2</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['email_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email_2" id="email_2" value=<?php echo e(old('email_2')); ?>>
                                <?php $__errorArgs = ['email_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.observacoes')); ?></label>
                                <textarea class="form-control" name="observacoes" id="observacoes" cols="30" rows="4"
                                    maxlength="100"><?php echo e(old('observacoes')); ?></textarea>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><?php echo e(__('text.condicoesEspeciais')); ?></label>
                                <textarea class="form-control" name="condicoes_especiais" id="condicoes_especiais"
                                    cols="30" rows="4" maxlength="100"><?php echo e(old('observacoes')); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('text.cancelar')); ?></button>
                    <button type="submit" class="btn btn-primary toastrDefaultSuccess1" ><?php echo e(__('text.guardar')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="modal-default2" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(__('text.informacaoFornecedor')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="font-weight-bold"><?php echo e(__('text.fornecedor')); ?>: <span id="nomeSpan"
                        class="font-weight-normal"></span>
                </p>
                <p class="font-weight-bold"><?php echo e(__('text.morada')); ?>: <span id="moradaSpan" class="font-weight-normal">
                    </span></p>
                <p class="font-weight-bold"><?php echo e(__('text.localizacao')); ?>: <span id="localizacaoSpan"
                        class="font-weight-normal"></span>
                </p>
                <p class="font-weight-bold"><?php echo e(__('text.telefone')); ?>: <span id="telefoneSpan"
                        class="font-weight-normal"></span></p>
                <p class="font-weight-bold">NIF: <span id="NIFSpan" class="font-weight-normal"></span></p>
                <p class="font-weight-bold">E-Mail: <span id="mailSpan" class="font-weight-normal"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.vendedor')); ?> 1: <span id="vendedorSpan"
                        class="font-weight-normal"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.telefone')); ?> 1: <span id="telefone1Span"
                        class="font-weight-normal"></span></p>
                <p class="font-weight-bold">E-Mail 1: <span id="mail1Span" class="font-weight-normal"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.vendedor')); ?> 2: <span id="vendedor2Span"
                        class="font-weight-normal"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.telefone')); ?> 2: <span id="telefone2Span"
                        class="font-weight-normal"></span></p>
                <p class="font-weight-bold">E-Mail 2: <span id="mail2Span" class="font-weight-normal"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.observacoes')); ?>: <span id="obserSpan"
                        class="font-weight-normal"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.condicoesEspeciais')); ?>: <span id="condiSpan"
                        class="font-weight-normal"></span></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="/js/mfb.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
        var table = $('#table').DataTable({
            "responsive": true,
            "autoWidth": false,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese.json'
            },
            "processing": true,
            "serverSide": true,
            "columnDefs": [ {
            "targets": -1,
            "orderable": false
            }],
            "ajax": "<?php echo e(route('APIFornecedores')); ?>",
            "columns": [
                { "data": 'designacao' },
                { "data": 'morada' },
                { "data": 'localidade' },
                { "data": 'codigo_postal' },
                { "data": 'telefone' },
                { "data": 'nif' },
                { "data": 'buttons' }
            ]
        });

        function elim(id){
        $('#eliminar').attr('action', '/fornecedores/'+id);
        $('#modal-default').modal('show');
    } 
    });
    
    <?php if(null !== session()->get( 'toast' )): ?>
        <?php if(session()->get( 'toast' )== 'editSuccess'): ?>
            toastr.success('<?php echo e(__('text.editadoSucesso')); ?>')
        <?php elseif(session()->get( 'toast' ) == 'elimSucess'): ?>
            toastr.success('<?php echo e(__('text.eliminadoSucesso')); ?>')
        <?php endif; ?>
    <?php endif; ?>
    
    function info(id,modal) {
        $.ajax({
               type:'GET',
               url:'api/fornecedor/'+id,
               success: function(info) {
                info = JSON.parse(info);
            if(modal){
                $('#modal-default2').modal('show');
                $('#nomeSpan').text(info.designacao);
                $('#moradaSpan').text(info.morada);
                $('#localizacaoSpan').text(info.localidade);
                $('#telefoneSpan').text(info.telefone);
                $('#codigoSpan').text(info.codigo_postal);
                $('#NIFSpan').text(info.nif);
                $('#mailSpan').text(info.email);
                $('#vendedorSpan').text(info.vendedor_1);
                $('#telefone1Span').text(info.telemovel_1);
                $('#mail1Span').text(info.email_1);
                $('#vendedor2Span').text(info.vendedor_2);
                $('#telefone2Span').text(info.telemovel_2);
                $('#mail2Span').text(info.email_2);
                $('#obserSpan').text(info.observacoes);
                $('#condiSpan').text(info.condicoes_especiais);
            }else{
                $('#edit').attr('action', '/fornecedores/'+info.id);
                $('#modal-default1').modal('show');
                $('#designacao').val(info.designacao);
                $('#morada').val(info.morada);
                $('#localidade').val(info.localidade);
                $('#telefone').val(info.telefone);
                $('#codigo_postal').val(info.codigo_postal);
                $('#nif').val(info.nif);
                $('#email').val(info.email);
                $('#vendedor_1').val(info.vendedor_1);
                $('#telemovel_1').val(info.telemovel_1);
                $('#email_1').val(info.email_1);
                $('#vendedor_2').val(info.vendedor_2);
                $('#telemovel_2').val(info.telemovel_2);
                $('#email_2').val(info.email_2);
                $('#observacoes').val(info.observacoes);
                $('#condicoes_especiais').val(info.condicoes_especiais);
            }
        }
        });
    }
    function elim(id){
        $('#eliminar').attr('action', '/fornecedores/'+id);
        $('#modal-default').modal('show');
    }
   
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/mfb.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/fornecedores.blade.php ENDPATH**/ ?>