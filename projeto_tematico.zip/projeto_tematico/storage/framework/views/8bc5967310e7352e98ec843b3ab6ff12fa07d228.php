<ul id="menu" class="mfb-component--br mfb-slidein" data-mfb-toggle="hover">
    <li class="mfb-component__wrap">
        <a href="#" data-mfb-label=<?php echo e(__('text.exportar')); ?> class="mfb-component__button--main">
            <i class="mfb-component__main-icon--resting fas fa-bars"></i>
        </a>
        <ul class="mfb-component__list">
            <li>
                <a href="#" id="excel" data-mfb-label="<?php echo e(__('text.exportarPara')); ?> Excel" class="mfb-component__button--child">
                    <i class="mfb-component__child-icon fas fa-plus"></i>
                </a>
            </li>
            <li>
                <a href="#" id="pdf" data-mfb-label="<?php echo e(__('text.exportarPara')); ?> PDF" class="mfb-component__button--child">
                    <i class="mfb-component__child-icon fas fa-file-pdf"></i>
                </a>
            </li>
            <li>
                <a href="#" id="csv" data-mfb-label="<?php echo e(__('text.exportarPara')); ?> CSV" class="mfb-component__button--child">
                    <i class="mfb-component__child-icon fas fa-file-csv"></i>
                </a>
            </li>

            <li>
                <a href="#" id="excel" data-mfb-label="<?php echo e(__('text.exportarPara')); ?> Excel" class="mfb-component__button--child">
                    <i class="mfb-component__child-icon fas fa-file-excel"></i>
                </a>
            </li>
        </ul>
    </li>
</ul>
<?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/sub-views/export-button.blade.php ENDPATH**/ ?>