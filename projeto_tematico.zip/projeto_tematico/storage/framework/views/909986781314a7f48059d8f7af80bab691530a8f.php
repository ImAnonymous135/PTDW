<?php $__env->startSection('content_header'); ?>
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark"><?php echo e($produto->designacao); ?></h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="../">Home</a></li>
          <li class="breadcrumb-item"><a href="../produtos"><?php echo e(__('text.produtos')); ?></a></li>
          <li class="breadcrumb-item active"><?php echo e(__('text.nomeProduto')); ?></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<ul id="menu" class="mfb-component--br mfb-slidein" data-mfb-toggle="hover">
  <li class="mfb-component__wrap">
    <a href="../entradas/<?php echo e($produto->id); ?>" data-mfb-label="Nova entrada" class="mfb-component__button--main">
      <i class="mfb-component__main-icon--resting fas fa-plus" style="font-size: 1.5rem;"></i>
    </a>
  </li>
</ul>

<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-header">
        <h3><?php echo e(__('text.informacaoProduto')); ?></h3>
      </div>
      <div class="card-body">
        <div>
          <?php if($produto->is_quimico): ?>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.formula')); ?>: <span
              class="font-weight-normal"><?php echo e($produto->quimico->formula); ?></span></p>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.pesoMolecular')); ?>: <span
              class="font-weight-normal"><?php echo e($produto->quimico->pMolecular); ?> g/mol</span></p>
          <p class="font-weight-bold mb-0">CAS Nº: <span class="font-weight-normal"><?php echo e($produto->quimico->casN); ?></span>
          </p>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.condicoesArmazenamento')); ?>: <span
              class="font-weight-normal"><?php echo e($produto->quimico->condicaoArmazenamento); ?></span></p>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.armarioVentilado')); ?>: <span class="font-weight-normal">
              <?php if($produto->quimico->ventilado): ?>
              <?php echo e(__('text.sim')); ?>

              <?php else: ?>
              <?php echo e(__('text.nao')); ?>

              <?php endif; ?>

            </span></p>
          <?php endif; ?>

          <p class="font-weight-bold mb-0"><?php echo e(__('text.unidades')); ?>: <span
              class="font-weight-normal"><?php echo e($produto->unidades->desginacao); ?></span></p>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.stockExistente')); ?>: <span
              class="font-weight-normal"><?php echo e($produto->stock_existente); ?></span></p>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.stockMinimo')); ?>: <span
              class="font-weight-normal"><?php echo e($produto->stock_minimo); ?></span></p>

          <?php if($produto->is_quimico): ?>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.recomendacoesPrudencias')); ?>: <span
              class="font-weight-normal"></span></p>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.advertenciaPerigos')); ?>: <span class="font-weight-normal"></span>
          </p>
          <p class="font-weight-bold mb-3"><?php echo e(__('text.pictogramas')); ?>:</p>
          <div>
            <?php $__currentLoopData = $produto->quimico->quimico_pictogramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pictograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img class="pictogramas" src="<?php echo e($pictograma->pictogramas->imagem); ?>" alt=""
            srcset="" width="100px" height="100px">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php else: ?>
          <p class="font-weight-bold mb-0"><?php echo e(__('text.familia')); ?>: <span
              class="font-weight-normal"><?php echo e($produto->nao_quimico->familia->designacao); ?></span></p>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-header">
        <h3><?php echo e(__('text.armazenamento')); ?></h3>
      </div>
      <div class="card-body">
        <div>
          <table id="table" class="table table-head-fixed">
            <thead>
              <tr>
                <th><?php echo e(__('text.localizacao')); ?></th>
                <th><?php echo e(__('text.capacidadeEmbalagem')); ?></th>
                <th><?php echo e(__('text.dataAbertura')); ?></th>
                <th><?php echo e(__('text.termino')); ?></th>
              </tr>
            </thead>
            <tbody>
              </tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<br>
<br>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/mfb.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('css/mfb.css')); ?>"></script>

<script>
  json = JSON.parse('<?php echo $embalagens ?>');
  dataSet = [];

  function dataAbertura(data, eID) {
    if (data == null) {
      return '<a href="/produtos/abertura/' + eID + '" type="button" data-toggle="tooltip" class="btn btn-primary"><?php echo e(__('text.registarAbertura')); ?></a>';
    }
    return data;
  }

  function terminar(dataAbertura, dataTermino, produto, embalagem) {
    if (dataAbertura == null || dataTermino != null )  {
      return '<button type="button" data-toggle="tooltip" class="btn btn-primary" disabled><?php echo e(__('text.termino')); ?></button>';
    }
    return '<a href="/saidas/'+produto+'/'+embalagem+'" type="button" data-toggle="tooltip" class="btn btn-primary"><?php echo e(__('text.termino')); ?></a>';
  }

  json.forEach(e => {
    dataSet.push([
      e.cliente+"-"+e.armario+"-"+e.prateleira,
      e.capacidade+" "+"<?php echo e($produto->unidades->desginacao); ?>",
      dataAbertura(e.data_abertura, e.embalagemid),
      terminar(e.data_abertura, e.data_termino, "<?php echo e($produto->designacao); ?>", e.embalagem)
    ]);
  });

  console.log(dataSet);

  $(function () {
    $('#table').DataTable({
      data: dataSet,
        "responsive": true,
        "autoWidth": false,
        "order": [[ 2, "asc" ]],
        language: {
                url: '//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese.json'
        }
    });
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/info-produto.blade.php ENDPATH**/ ?>