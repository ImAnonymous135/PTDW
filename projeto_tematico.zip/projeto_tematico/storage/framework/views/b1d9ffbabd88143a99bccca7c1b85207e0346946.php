<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">
                    <?php echo e(__('text.adicionarProduto')); ?>

                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="../">Home</a></li>
                    <li class="breadcrumb-item "><a href="../produtos"><?php echo e(__('text.produtos')); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('text.add')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="form" method="post" action="/produtos/adicionar">
    <?php echo csrf_field(); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-2">
                    <div class="form-group">
                        <label><?php echo e(__('text.tipo')); ?></label>
                        <select class="form-control" id="selectTipo" name="selectTipo">
                            <option selected="selected" value="0">Químico</option>
                            <option value="1">Não Químico</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label><?php echo e(__('text.designacao')); ?></label>
                        <input name="designacao" id="designacao" type="text"
                            class="form-control <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label><?php echo e(__('text.sinonimos')); ?></label>
                        <input disabled type="text" class="form-control" id="sinonimos" name="sinonimos">
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-sm-2">
                    <div class="form-group">
                        <label><?php echo e(__('text.unidades')); ?></label>
                        <div class="input-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['unidades'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="unidades" name="unidades">
                        </div>
                        <?php $__errorArgs = ['unidades'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="form-group">
                        <label><?php echo e(__('text.stockMinimo')); ?></label>
                        <input name="stockMinimo" id="stockMinimo" type="text"
                            class="form-control <?php $__errorArgs = ['stockMinimo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['stockMinimo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-2">
                    <div class="quimico" style="display:block;">
                        <div class="form-group">
                            <label><?php echo e(__('text.pesoMolecular')); ?></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['pesoMolecular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="pesoMolecular" name="pesoMolecular">
                            <?php $__errorArgs = ['pesoMolecular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="naoQuimico1" style="display:none;">
                        <div class="form-group">
                            <label>Familia</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['familia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="familia"
                                name="familia">
                            <?php $__errorArgs = ['familia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="quimico1" style="display:block;">
                        <div class="form-group">
                            <label><?php echo e(__('text.condicoesArmazenamento')); ?></label>
                            <input type="text"
                                class="form-control <?php $__errorArgs = ['condicoesArmazenamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="condicoesArmazenamento" name="condicoesArmazenamento">
                            <?php $__errorArgs = ['condicoesArmazenamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="naoQuimico" style="display:none;">
                        <div class="form-group">
                            <label for="exampleInputFile">Fotografia</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file"
                                        class="custom-file-input <?php $__errorArgs = ['fotografia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="fotografia" name="fotografia">
                                    <label class="custom-file-label" for="exampleInputFile">Escolha
                                        a fotografia</label>
                                </div>
                            </div>
                            <?php $__errorArgs = ['fotografia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">

                <div class="col-sm-2">
                    <div class="quimico2" style="display:block;">
                        <div class="form-group">
                            <label><?php echo e(__('text.formula')); ?></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['formula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="formula"
                                name="formula">
                            <?php $__errorArgs = ['formula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                </div>

                <div class="col-sm-2">
                    <div class="quimico3" style="display:block;">
                        <div class="form-group">
                            <label>Nº CAS</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nCas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nCas"
                                name="nCas">
                            <?php $__errorArgs = ['nCas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                </div>

                <div class="col-sm-2">
                    <div class="quimico4" style="display:block;">
                        <div class="form-group">
                            <label><?php echo e(__('text.anexo')); ?> SDS</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input disabled type="file"
                                        class="custom-file-input <?php $__errorArgs = ['anexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="anexo"
                                        name="anexo">
                                    <label class="custom-file-label" for="exampleInputFile"></label>
                                </div>
                            </div>
                            <?php $__errorArgs = ['anexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <div class="quimico7" style="display:block;">
                        <div class="form-group">
                            <label><?php echo e(__('text.codigoPerigo')); ?></label>
                            <input type="text" class="form-control" disabled id="">
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="quimico5" style="display:block;">
                        <div class="form-group">
                            <label><?php echo e(__('text.codigoPrudencia')); ?></label>
                            <input type="text" class="form-control" disabled id="">
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="quimico8" style="display:block;">
                        <div class="form-group">
                            <div class="form-check align-middle">
                                <input type="checkbox" class="form-check-input" id="ventilado" name="ventilado">
                                <label for="ventilado"><?php echo e(__('text.ventilado')); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <label class="quimico10"><?php echo e(__('text.pictogramas')); ?></label>
            <div class="row quimico9">
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="skull" id="skull">
                    <label for="skull"><img src="https://www.reach-compliance.ch/downloads/GHS06_skull.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="explosive" id="explosive">
                    <label for="explosive"><img src="https://www.reach-compliance.ch/downloads/GHS01_explos.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="flame" id="flame">
                    <label for="flame"><img src="https://www.reach-compliance.ch/downloads/GHS02_flamme.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="flame2" id="flame2">
                    <label for="flame2"><img src="https://www.reach-compliance.ch/downloads/GHS03_rondflam.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="bottle" id="bottle">
                    <label for="bottle"><img src="https://www.reach-compliance.ch/downloads/GHS04_bottle.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="acid" id="acid">
                    <label for="acid"><img src="https://www.reach-compliance.ch/downloads/GHS05_acid_red.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="danger" id="danger">
                    <label for="danger"><img src="https://www.reach-compliance.ch/downloads/GHS07_exclam.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="lungs" id="lungs">
                    <label for="lungs"><img src="https://www.reach-compliance.ch/downloads/GHS08_silhouete.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
                <div class="picto-holder">
                    <input class="picto-input" type="checkbox" name="pollution" id="pollution">
                    <label for="pollution"><img src="https://www.reach-compliance.ch/downloads/GHS09_aq-pollut.png" alt="" srcset=""
                            width="100px" height="100px"></label>
                </div>
            </div>

            <div>
                <div class="d-flex flex-row justify-content-end">
                    <span class="mr-2">
                        <button type="button" class="btn btn-block btn-outline-primary"
                            onclick="window.location.href='../produtos'"><?php echo e(__('text.cancelar')); ?></button>
                    </span>
                    <span class="mr-2">
                        <input type="submit" class="btn btn-block btn-primary"></button>
                    </span>
                </div>
            </div>
        </div>
    </div>
</form>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/adicionar.js')); ?>"></script>
<script src="<?php echo e(asset('js/pictogramas.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/pictogramas.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/adicionar-produto.blade.php ENDPATH**/ ?>