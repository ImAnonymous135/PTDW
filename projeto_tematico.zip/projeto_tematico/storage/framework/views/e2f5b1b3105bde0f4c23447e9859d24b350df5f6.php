<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">
                    <?php echo e(__('text.adicionarCliente')); ?>

                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="../">Home</a></li>
                    <li class="breadcrumb-item "><a href="../clientes"><?php echo e(__('text.clientes')); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('text.add')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
        #alert-box{
  /*display:block;*/
   position:fixed;
   width:300px;
   padding:5px 20px 20px;
   background:#ddd;
   border:1px solid #999;
   text-align:center;
   transform:translate(-50%,-50%);
   top:50%;
   left:50%;
   z-index:99999;
   -webkit-box-shadow: 0px 0px 33px -6px rgba(0,0,0,0.59);
   -moz-box-shadow: 0px 0px 33px -6px rgba(0,0,0,0.59);
   box-shadow: 0px 0px 33px -6px rgba(0,0,0,0.59);
}

</style>
<?php if(\Session::has('msg')): ?>
        
        
<script>
let msg_alerta = '<div id="alert-box" style="display:block;">'
+'<h1>Aviso</h1>'
+'<p><?php echo \Session::get("msg"); ?></p>'
+'<input style="padding:5px 10px;" type="button" value="OK" onClick="togglePopup();" />'
+'</div>';
document.write(msg_alerta);


function togglePopup() {
    if (document.getElementById('alert-box').style.display == 'block') {
        document.getElementById('alert-box').style.display = 'none';
    }
}

</script>
<?php endif; ?>
<div class="card">
    <div class="card-body">
    <form method="POST" action="/clientes/adicionar">
    <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <label><?php echo e(__('text.designacao')); ?></label>
                    <input type="text"  class="form-control <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="designacao" name="designacao" value=<?php echo e(old('designacao')); ?>>
                    <?php $__errorArgs = ['designacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.nomeResponsavel')); ?></label>
                    <input type="text"  class="form-control <?php $__errorArgs = ['nomeResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomeResponsavel" name="nomeResponsavel" value=<?php echo e(old('nomeResponsavel')); ?>>
                    <?php $__errorArgs = ['nomeResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.emailResponsavel')); ?></label>
                    <input  type="text" class="form-control <?php $__errorArgs = ['emailResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="emailResponsavel" name="emailResponsavel" value=<?php echo e(old('emailResponsavel')); ?>>
                    <?php $__errorArgs = ['emailResponsavel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.nomeSolicitante')); ?></label>
                    <input type="text"  class="form-control" id="nomeSolicitante" name="nomeSolicitante" value=<?php echo e(old('nomeSolicitante')); ?>>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label><?php echo e(__('text.emailSolicitante')); ?></label>
                    <input type="text"   class="form-control <?php $__errorArgs = ['emailSolicitante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="emailSolicitante" name="emailSolicitante" value=<?php echo e(old('emailSolicitante')); ?>> 
                    <?php $__errorArgs = ['emailSolicitante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <label><?php echo e(__('text.observacoes')); ?></label>
                    <textarea class="form-control" id="observacoes" name="observacoes" cols="30" rows="4" maxlength="100" ><?php echo e(old('observacoes')); ?></textarea>
                </div>
            </div>
        </div>
        <div>
            <div class="d-flex flex-row justify-content-end">
                <span class="mr-2">
                    <button type="button" class="btn btn-block btn-outline-primary"
                        onclick="window.location.href='../clientes'"><?php echo e(__('text.cancelar')); ?></button>
                </span>
                <span class="mr-2">
                    <button type="submit" class="btn btn-block btn-primary"><?php echo e(__('text.submeter')); ?></button>
                </span>
            </div>
        </div>
        </form>
    </div>
    
</div>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/adicionar-cliente.blade.php ENDPATH**/ ?>