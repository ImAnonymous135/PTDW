<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo e(__('text.operadores')); ?></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('text.operadores')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!--
    Adicionar o botao no final para a ação como eliminar ou mudar de cargo ou assim
-->
<?php $__env->startSection('content'); ?>

<ul id="menu" class="mfb-component--br mfb-slidein" data-mfb-toggle="hover">
    <li class="mfb-component__wrap">
        <a data-mfb-label="<?php echo e(__('text.novoOperador')); ?>" class="mfb-component__button--main" href="../operadores/adicionar">
            <i class="mfb-component__main-icon--resting fas fa-plus" style="font-size: 1.5rem;"></i>
        </a>
    </li>
</ul>

<div class="card">
    <div class="card-body">
        <table id="table" class="table table-head-fixed">
            <thead>
                <tr>
                    <th><?php echo e(__('text.nome')); ?></th>
                    <th>E-Mail</th>
                    <th><?php echo e(__('text.perfil')); ?></th>
                    <th><?php echo e(__('text.dataCriacao')); ?></th>
                    <th><?php echo e(__('text.dataEliminacao')); ?></th>
                    <th><?php echo e(__('text.acoes')); ?></th>
                </tr>
            </thead>
        </table>
    </div>
    <!-- /.card-body -->
</div>
<br>


<div class="modal fade" id="modal-default" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <form method="POST" id="eliminar">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(__('text.eliminar')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <p><?php echo e(__('text.confirmarEliminarOperador')); ?></p>
            <div class="form-group">
                    <label><?php echo e(__('text.observacoes')); ?></label>
                    <textarea class="form-control" id="observacoes" name="observacoes" cols="30" rows="4" maxlength="100"><?php echo e(old('observacoes')); ?></textarea>
                </div>
                </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('text.nao')); ?></button>
                <button type="submit" class="btn btn-primary toastrDefaultSuccess"><?php echo e(__('text.sim')); ?></button>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="modal-default1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(__('text.editarCargo')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form method="POST" id="edit">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
            <div class="modal-body">
                <label><?php echo e(__('text.novoCargoOperador')); ?></label>
                <select name="novoCargoOperador" id="novoCargoOperador" class="custom-select">
                    <?php $__currentLoopData = $perfil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($perfil->id); ?>"><?php echo e($perfil->perfil); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="form-group">
                    <label><?php echo e(__('text.observacoes')); ?></label>
                    <textarea class="form-control" id="observacoes" name="observacoes" cols="30" rows="4" maxlength="100"><?php echo e(old('observacoes')); ?></textarea>
                </div>
            </div>
            
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('text.cancelar')); ?></button>
                <button type="submit" class="btn btn-primary toastrDefaultSuccess1"><?php echo e(__('text.guardar')); ?></button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal fade" id="modal-default2" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e(__('text.informacaoOperador')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="font-weight-bold"><?php echo e(__('text.nome')); ?>: <span class="font-weight-normal" id="nome"></span></p>
                <p class="font-weight-bold">E-Mail: <span class="font-weight-normal" id="email"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.perfil')); ?>: <span class="font-weight-normal" id="perfil"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.dataCriacao')); ?>: <span class="font-weight-normal" id="dataCriacao"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.dataEliminacao')); ?>: <span class="font-weight-normal" id="dataEliminacao"></span></p>
                <p class="font-weight-bold"><?php echo e(__('text.observacoes')); ?>: <span class="font-weight-normal" id="observacoes"></span></p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<br>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
<?php if(null !== session()->get( 'toast' )): ?>
        <?php if(session()->get( 'toast' )== 'editSuccess'): ?>
            toastr.success('<?php echo e(__('text.editadoSucesso')); ?>')
        <?php elseif(session()->get( 'toast' ) == 'deleteSuccess'): ?>
            toastr.success('<?php echo e(__('text.eliminadoSucesso')); ?>')
        <?php elseif(session()->get( 'toast' ) == 'error'): ?>
            toastr.error('erro')
        <?php endif; ?>
    <?php endif; ?>
    
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();
    });
</script>
<script>
    $(function () {
        $('#table').DataTable({
        "responsive": true,
        "autoWidth": false,
        language: {
                url: '//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese.json'
        },
        "processing": true,
            "serverSide": true,
            "ajax": "<?php echo e(route('APIlistaOperadores')); ?>",
            "columns": [
                { "data": 'nome' },
                { "data": 'email' },
                { "data": 'perfil' },
                { "data": 'data_criação' },
                { "data": 'data_eliminação'},
                {"data" : 'buttons'}
            ]
    });
  
  });
  function elim(id){
        $('#eliminar').attr('action', '/operadores/'+id);
        $('#modal-default').modal('show');
    }

    function info(id,modal) {
        $.ajax({
               type:'GET',
               url:'api/operadores/'+id,
               success: function(info) {
                info = JSON.parse(info);
            if(modal){
                console.dir(info);
                $('#modal-default2').modal('show');
                $('#nome').text(info[0].nome);
                $('#email').text(info[0].email);
                $('#perfil').text(info[0].perfil);
                $('#dataCriacao').text(info[0].data_criação);
                $('#dataEliminacao').text(info[0].data_eliminação);
                $('#observacoes').text(info[0].observacoes);
            }else{
                $('#edit').attr('action', '/operadores/'+id);
                $('#modal-default1').modal('show');
                $('#novoCargoOperador').val(info[0].perfil);
            }
        }
        });
        console.dir(info);
        console.dir(modal);
    }

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
<link href="<?php echo e(asset('css/mfb.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/operadores.blade.php ENDPATH**/ ?>