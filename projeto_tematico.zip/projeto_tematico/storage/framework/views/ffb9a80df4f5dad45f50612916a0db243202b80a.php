<?php $__env->startSection('content_header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo e(__('text.entradas')); ?></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="../">Home</a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('text.movimentosNaoQuimicos')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('sub-views.export-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="font-weight-normal"><?php echo e(__('text.periodoEntrada')); ?>:</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="far fa-calendar-alt"></i>
                            </span>
                        </div>
                        <input type="text" class="form-control float-right" id="data">
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="font-weight-normal"><?php echo e(__('text.familia')); ?>:</label>
                    <div class="input-group-prepend">
                        <select id="familia" class="select2 form-control" name="subfamilia[]" multiple="multiple">
                            <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($familia->designacao); ?>"><?php echo e($familia->designacao); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label class="font-weight-normal"><?php echo e(__('text.tipoEmbalagem')); ?>:</label>
                <div class="input-group-prepend">
                    <select id="pesquisa" class="select form-control" name="pesquisa">
                        <option value="produto">Produto</option>
                        <option value="prateleira">Prateleira</option>
                        <option value="armario">Armario</option>
                        <option value="cliente">Cliente</option>
                        <option value="fornecedor">Fornecedor</option>
                        <option value="marca">Marca</option>
                        <option value="tipo">Tipo de Embalagem</option>
                        <option value="cor">Cor</option>
                        <option value="peso">Peso Bruto</option>
                    </select>
                </div>
            </div>
        </div>

        <table id="table" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th name="designacao"><?php echo e(__('text.produto')); ?></th>
                    <th><?php echo e(__('text.localizacao')); ?></th>
                    <th><?php echo e(__('text.fornecedor')); ?></th>
                    <th><?php echo e(__('text.marca')); ?></th>
                    <th><?php echo e(__('text.familia')); ?></th>
                    <th><?php echo e(__('text.tipoEmbalagem')); ?></th>
                    <th><?php echo e(__('text.cor')); ?></th>
                    <th><?php echo e(__('text.pesoBruto')); ?></th>
                    <th><?php echo e(__('text.dataEntrada')); ?></th>
                    <th><?php echo e(__('text.dataValidade')); ?></th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/mfb.js')); ?>"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>
    $(function () {
        $('#familia').select2();
        
        var table = $('#table').DataTable({
            "responsive": true,
            "autoWidth": false,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese.json'
            },
            "processing": true,
            "serverSide": true,
            "ajax": "<?php echo e(route('APIEntradaNaoQuimicos')); ?>",
            "columns": [
                { "data": 'designacao' },
                { "data": 'localizacao'},
                { "data": 'fornecedor' },
                { "data": 'marca' },
                { "data": 'familia' },
                { "data": 'tipo_embalagem' },
                { "data": 'cor' },
                { "data": 'peso' },
                { "data": 'data_entrada' },
                { "data": 'data_validade' },
            ]
        });

        table.on('preXhr.dt', function (e, settings, data) {
            var temp = $('#data').val().split("-");
            if (temp[0] != temp[1]) {
                data.start_date = temp[0];
                data.end_date = temp[1];
            }
            data.tipo = $('#familia').val();
            data.pesquisa = $('#pesquisa').val();
        });

        $('#data').daterangepicker({
            autoUpdateInput: true,
            locale: {
                format: 'DD/MM/YYYY',
                cancelLabel: 'Clear'
            }
        });

        $('#data').on('cancel.daterangepicker', function (ev, picker) {
            $('#data').val('');
            $('#data').data('daterangepicker').setStartDate(new Date());
            $('#data').data('daterangepicker').setEndDate(new Date());
            table.draw();
        });

        $('#data').on('apply.daterangepicker', function (ev, picker) {
            table.draw();
        });

        $('#familia').on('select2:select select2:unselect', function (ev, picker) {
            table.draw();
        });

        $('#pesquisa').on('change', function () {
            table.draw();
        })
    });
</script>
<?php echo $__env->make('sub-views.exports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/mfb.css')); ?>" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/PTDW/PTDW/projeto_tematico/resources/views/entrada-nao-quimico.blade.php ENDPATH**/ ?>